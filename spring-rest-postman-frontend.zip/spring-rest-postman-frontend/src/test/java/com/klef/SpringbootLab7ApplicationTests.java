package com.klef;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootLab7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
